<?php


namespace App\Http\Resources\UpdateNote;


use Illuminate\Http\Resources\Json\ResourceCollection;

class UpdateNoteCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
