<?php


namespace App\Http\Resources\SupplierAdvance;


use Illuminate\Http\Resources\Json\ResourceCollection;

class SupplierAdvanceCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
