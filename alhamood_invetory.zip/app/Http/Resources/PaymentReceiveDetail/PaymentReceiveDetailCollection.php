<?php


namespace App\Http\Resources\PaymentReceiveDetail;


use Illuminate\Http\Resources\Json\ResourceCollection;

class PaymentReceiveDetailCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
