<?php


namespace App\Http\Resources\SupplierPayment;


use Illuminate\Http\Resources\Json\ResourceCollection;

class SupplierPaymentCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
