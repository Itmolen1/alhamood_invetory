<?php


namespace App\Http\Resources\CompanyType;


use Illuminate\Http\Resources\Json\ResourceCollection;

class CompanyTypeCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
