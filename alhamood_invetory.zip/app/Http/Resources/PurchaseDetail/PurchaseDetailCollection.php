<?php


namespace App\Http\Resources\PurchaseDetail;


use Illuminate\Http\Resources\Json\ResourceCollection;

class PurchaseDetailCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
