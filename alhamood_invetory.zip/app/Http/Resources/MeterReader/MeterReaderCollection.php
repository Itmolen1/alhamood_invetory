<?php


namespace App\Http\Resources\MeterReader;


use Illuminate\Http\Resources\Json\ResourceCollection;

class MeterReaderCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
