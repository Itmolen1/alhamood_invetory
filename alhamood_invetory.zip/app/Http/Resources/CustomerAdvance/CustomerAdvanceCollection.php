<?php


namespace App\Http\Resources\CustomerAdvance;


use Illuminate\Http\Resources\Json\ResourceCollection;

class CustomerAdvanceCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
