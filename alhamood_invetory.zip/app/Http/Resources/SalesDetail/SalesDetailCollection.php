<?php


namespace App\Http\Resources\SalesDetail;


use Illuminate\Http\Resources\Json\ResourceCollection;

class SalesDetailCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
