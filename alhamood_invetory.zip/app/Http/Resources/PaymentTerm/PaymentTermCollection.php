<?php


namespace App\Http\Resources\PaymentTerm;


use Illuminate\Http\Resources\Json\ResourceCollection;

class PaymentTermCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
