<?php


namespace App\Http\Resources\PaymentReceive;


use Illuminate\Http\Resources\Json\ResourceCollection;

class PaymentReceiveCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
