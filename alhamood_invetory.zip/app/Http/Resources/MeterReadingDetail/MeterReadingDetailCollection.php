<?php


namespace App\Http\Resources\MeterReadingDetail;


use Illuminate\Http\Resources\Json\ResourceCollection;

class MeterReadingDetailCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
