<?php

namespace App\Http\Controllers;

use App\Models\MeterReadingDetail;
use Illuminate\Http\Request;

class MeterReadingDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MeterReadingDetail  $meterReadingDetail
     * @return \Illuminate\Http\Response
     */
    public function show(MeterReadingDetail $meterReadingDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MeterReadingDetail  $meterReadingDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(MeterReadingDetail $meterReadingDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MeterReadingDetail  $meterReadingDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MeterReadingDetail $meterReadingDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MeterReadingDetail  $meterReadingDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(MeterReadingDetail $meterReadingDetail)
    {
        //
    }
}
