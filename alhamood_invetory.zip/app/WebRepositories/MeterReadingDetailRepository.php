<?php
/**
 * Created by PhpStorm.
 * User: rizwanafridi
 * Date: 11/25/20
 * Time: 11:13
 */

namespace App\WebRepositories;


use App\WebRepositories\Interfaces\IMeterReadingDetailRepositoryInterface;
use Illuminate\Http\Request;

class MeterReadingDetailRepository implements IMeterReadingDetailRepositoryInterface
{

    public function index()
    {
        // TODO: Implement index() method.
    }

    public function create()
    {
        // TODO: Implement create() method.
    }

    public function store(Request $request)
    {
        // TODO: Implement store() method.
    }

    public function update(Request $request, $Id)
    {
        // TODO: Implement update() method.
    }

    public function getById($Id)
    {
        // TODO: Implement getById() method.
    }

    public function edit($Id)
    {
        // TODO: Implement edit() method.
    }

    public function delete(Request $request, $Id)
    {
        // TODO: Implement delete() method.
    }

    public function restore($Id)
    {
        // TODO: Implement restore() method.
    }

    public function trashed()
    {
        // TODO: Implement trashed() method.
    }
}